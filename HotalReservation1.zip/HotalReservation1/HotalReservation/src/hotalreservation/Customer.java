package hotalreservation;

public class Customer {
   private int id;
   private String name;
   private String mobil_number;   
    
   public int getId(){
        return this.id;
    }
    public void setId(int id){
        this.id=id;
    }
    
    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name=name;
    }
    
    public String getMobil(){
        return this.mobil_number;
    }
    public void setMobil(String mobil){
        this.mobil_number=mobil;
    }
        
}
