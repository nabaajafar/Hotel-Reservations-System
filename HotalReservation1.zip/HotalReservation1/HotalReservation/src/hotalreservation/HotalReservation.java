
package hotalreservation;

import java.util.ArrayList;
import java.util.Scanner;
public class HotalReservation {

    public static void main(String[] args) {
      ArrayList<Reservation> reservation=new ArrayList<>();  
      Scanner input=new Scanner(System.in);
      Scanner inputSt=new Scanner(System.in); 
      int counter=0;// to count numbers of rooms
      int counterRe=0;//to count numbers of reservation
      Reservation resev=new Reservation(); 
      Rooms room=new Rooms();
      System.out.println("HOTRL MANAGEMENT APPLICATION!"); 
      System.out.println("&&&&&&&&&&&& Main List &&&&&&&&&&&&\n");
      System.out.println("[1] Adminstrator\n[2]Customer\n[0]Exit\nyour choice: "); 
      int c=input.nextInt();
      while (c!=0) {
       switch(c){
         case 1:
           System.out.println("\n[1]Add Room\n[2]View all Rooms in hotal\n[3]updat Room's price\n[4]delete Room\n[0]Return to the main menu\nyour choice: ");
           int b=input.nextInt();
           while(b!=0){
           switch(b){
               case 1:
              
                System.out.println("\n****Add Room****\n");
                System.out.println("Enter Room number : ");
                room.setNum(input.nextInt());
                System.out.println("Enter Room's price  : ");
                room.setPrice(input.nextDouble());
                resev.addRooms(room);
                counter++;
                 break;
                   
               case 2:
                   if(counter==0){
                       System.out.println("NO ROOMS");
                   }
                   else{
                    System.out.println("\n****Display all Rooms****\n");
                     for(int j=0;j<counter;j++){
                         System.out.printf("%-20s %-15s \n","Room's Number", "Room's price");
                     System.out.printf("%-20s %-15s \n", room.getNum(),room.getPrice());
                      //System.out.println("Room number\tPrice");
                      //System.out.println(room.getNum()+"\t"+room.getPrice());
                      }//ends for loop for case 2 inside case 1 
                   }//ends else
                 break;  
                   
               case 3:
                   
                   break;
               case 4:
                   
                   break;
               default:
                   System.out.println("INVALID INPUT!!");
           }//end switch for admin
           
         System.out.println("\n[1]Add Room\n[2]View all Rooms in hotal\n[3]updat Room's price\n[4]delete Room\n[0]Return to the main menu\nyour choice: ");
           b=input.nextInt();
          }//end while admin
             break;
             
       case 2:
        System.out.println("[1]Booking a room\n[2]View reserved rooms\n[3]udate number of night\n[4]Check out[0]Return to the main menu\nyour choice:");
        int f=input.nextInt();
        while (f!=0){
            switch(f){
                case 1:
                System.out.println("\n*****Booking*****\n");
                if(counter==0){
                       System.out.println("\nSORRY THE ADMINSTRATOR DID NOT ROOMS\n");
                   }
                else{
                Customer cu = new Customer();
                
                System.out.println("Please enter customer'ID: ");
                cu.setId(input.nextInt());
                System.out.println("Please enter customer name : ");
                cu.setName(inputSt.nextLine());
                System.out.println("Please enter customer mobile : ");
                cu.setMobil(inputSt.nextLine());
                System.out.println("Please enter number of nights of stay");///put exception
                resev.setNight(input.nextInt());
                System.out.println("How many rooms do you want to reserved: ");
                int roomNum = input.nextInt();
                for (int i=0;i<roomNum;i++) {
                System.out.println("enter Room number");
                int numRoom=input.nextInt();
                reservation.add(resev);
                counterRe++;
                }//end for
                }//end else
                break;
            
                case 2:
                 if(counterRe==0){
                        System.out.println("NO RESERVATION");
                    }
                 System.out.println("\n****Display reserve Rooms****\n");
                 for(int i=0;i<reservation.size();i++){
                   Reservation re=reservation.get(i);
                   for(int j=0;j<re.getRooms().size();j++){
                     Rooms ro=re.getRooms().get(i);
                     System.out.printf("%-20s %-15s %s \n","Room's Number", "Room's price","Number of Night");
                     System.out.printf("%-20s %-15s  %s\n", ro.getNum(),ro.getPrice(),re.getNight());
                    // System.out.println("Room number\tPrice\tNumber of night");
                     //System.out.println(ro.getNum()+"\t"+ro.getPrice()+"\t"+re.getNight());
                      }//ends inner for loop for case 2 inside case 1       
                     }//ends outer for loop for case 2 inside case 1
                    break;
                    
                case 3: 
                    break;
                    
                case 4:
                    break;
                default:
                    System.out.println("INVALID INPUT!!"); 
                
                
            }//end switch of customer
           System.out.println("[1]Booking a room\n[2]View reserved rooms\n[3]udate number of night\n[4]Check out\n[0]Return to the main menu\nyour choice:");
           f=input.nextInt();
           }//end while for customer
     }//end main switch
     System.out.println("\n&&&&&&&&&&&& Main List &&&&&&&&&&&&\n");
     System.out.println("[1] Adminstrator\n[2]Customer\n[0]Exit\nyour choice: "); 
     c=input.nextInt(); 
    }//end main while
        System.out.println("THANK YOU\nGOODBYE");
     }//ends main
    }//ends class
   