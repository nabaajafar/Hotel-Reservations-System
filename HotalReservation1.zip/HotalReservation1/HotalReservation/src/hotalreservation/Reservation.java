
package hotalreservation;

import java.util.ArrayList;
public class Reservation {
private int night;  
private  Customer coustomer=new Customer(); 
private ArrayList<Rooms> rooms=new ArrayList<>(); 

public Reservation(int night,ArrayList<Rooms> rooms,Customer coustomer) {
    this.night = night;
    this.coustomer=coustomer;
    this.rooms=rooms;
        
    }
    
     public Reservation(){}
     
     public int getNight(){
       return this.night;
    }
    public void setNight(int night){
        this.night=night;
    }
    
    public void setCustomer(Customer c){
        this.coustomer=c;
    }
    public Customer getCustomer(){
        return this.coustomer ;
    } 
    
     public ArrayList<Rooms> getRooms(){
        return this.rooms;
    }
    public void addRooms(Rooms r){
        rooms.add(r);
    }
    
    
}
