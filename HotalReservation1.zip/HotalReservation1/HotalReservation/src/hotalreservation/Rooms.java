
package hotalreservation;

public class Rooms {
    private int num;
    private double price;
    private boolean booked=false;
    
    public Rooms(){}
    public Rooms(int num,double price){
        this.num=num;
        this.price=price;
    }
    
    public int getNum(){
        return this.num;
    }
    public void setNum(int num){
        this.num=num;
    }
    
    public double getPrice(){
        return this.price;
    }
    public void setPrice(double price){
        this.price=price;
    }
    
   public void cancel(){
        booked=false;
    }
    public boolean isBooked(){
       return booked; 
    }
    
    public void setBooked(boolean booked){
        this.booked=booked;
    }
   
    public String toString(){
        return" Room's Number: "+this.getNum()+" Room's Price: "+this.getPrice();
    }
}
